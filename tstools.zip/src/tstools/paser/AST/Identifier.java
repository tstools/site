package tstools.paser.AST;

import com.google.javascript.jscomp.parsing.parser.util.SourceRange;
import tstools.paser.ExpressionVisitor;

/**
 * Created by  *  on 01-09-2015.
 */
public class Identifier extends Expression {
    private  String name;
    public Identifier declaration = null;
    public boolean isGlobal = false;

    public Identifier(SourceRange location, String name) {
        super(location);
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Identifier getDeclaration() {
        return declaration;
    }

    @Override
    public <T> T accept(ExpressionVisitor<T> visitor) {
        return visitor.visit(this);
    }
    public void setName(String newName) {
        this.name = newName;
    }

}
