package tstools.paser.AST;

import tstools.paser.ExpressionTransverse;
import tstools.paser.ExpressionVisitor;
import tstools.paser.StatementTransverse;
import tstools.paser.StatementVisitor;

/**
 * A default implementation of NodeVisitor, that visits everything, but returns null for everything.
 */

public interface NodeTransverse<T> extends StatementTransverse<T>, ExpressionTransverse<T> {
    @Override
    public default ExpressionVisitor<T> getExpressionVisitor() {
        return this;
    }

    @Override
    public default StatementVisitor<T> getStatementVisitor() {
        return this;
    }
}
