package tstools.paser.AST;

import com.google.javascript.jscomp.parsing.parser.util.SourceRange;
import tstools.paser.ExpressionVisitor;

/**
 * Created by  *  on 07-09-2015.
 */
public class ThisExpression extends Expression {
    public ThisExpression(SourceRange loc) {
        super(loc);
    }

    @Override
    public <T> T accept(ExpressionVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
