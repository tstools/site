package tstools.paser.AST;

import com.google.javascript.jscomp.parsing.parser.util.SourceRange;
import tstools.paser.ExpressionVisitor;

/**
 * Created by * on 01-09-2015.
 */
public class StringLiteral extends Expression {
    private String string;

    public StringLiteral(SourceRange location, String string) {
        super(location);
        this.string = string;
    }

    @Override
    public <T> T accept(ExpressionVisitor<T> visitor) {
        return visitor.visit(this);
    }

}
