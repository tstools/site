package tstools.paser.AST;

import tstools.paser.ExpressionVisitor;
import tstools.paser.StatementVisitor;

/**
 * Created by  *  on 01-09-2015.
 */
public interface NodeVisitor<T> extends StatementVisitor<T>, ExpressionVisitor<T> {

}
