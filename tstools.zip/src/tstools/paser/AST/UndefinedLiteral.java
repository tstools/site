package tstools.paser.AST;

import com.google.javascript.jscomp.parsing.parser.util.SourceRange;
import tstools.paser.ExpressionVisitor;

/**
 * Created by * on 01-09-2015.
 */
public class UndefinedLiteral extends Expression {
    UndefinedLiteral(SourceRange location) {
        super(location);
    }

    @Override
    public <T> T accept(ExpressionVisitor<T> visitor) {
        return visitor.visit(this);
    }
}
