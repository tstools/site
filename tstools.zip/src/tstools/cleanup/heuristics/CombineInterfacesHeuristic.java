package tstools.cleanup.heuristics;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import tstools.Score;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.InterfaceDeclarationType;
import tstools.analysis.declarations.types.UnnamedObjectType;
import tstools.cleanup.CollectEveryTypeVisitor;
import tstools.cleanup.DeclarationTypeToTSTypes;
import tstools.cleanup.RedundantInterfaceCleaner;
import tstools.declarationReader.DeclarationParser;
import tstools.evaluation.Evaluation;
import tstools.util.Util;

import java.util.*;

import static tstools.cleanup.heuristics.HeuristicsUtil.*;
import static tstools.cleanup.heuristics.HeuristicsUtil.hasDynAccess;
import static tstools.cleanup.heuristics.HeuristicsUtil.hasObject;
import static tstools.cleanup.heuristics.HeuristicsUtil.numberOfFields;

/**
 * Created by * on 15-03-2016.
 */
public class CombineInterfacesHeuristic implements ReplacementHeuristic{

    private final DeclarationParser.NativeClassesMap nativeClasses;
    private final DeclarationTypeToTSTypes decsToTS;
    private RedundantInterfaceCleaner redundantInterfaceCleaner;

    public CombineInterfacesHeuristic(DeclarationParser.NativeClassesMap nativeClasses, DeclarationTypeToTSTypes decsToTS, RedundantInterfaceCleaner redundantInterfaceCleaner) {
        this.nativeClasses = nativeClasses;
        this.decsToTS = decsToTS;
        this.redundantInterfaceCleaner = redundantInterfaceCleaner;
    }

    @Override
    public Multimap<DeclarationType, DeclarationType> findReplacements(CollectEveryTypeVisitor collected) {
        ArrayListMultimap<DeclarationType, DeclarationType> replacements = ArrayListMultimap.create();

        Map<Class<? extends DeclarationType>, Set<DeclarationType>> byType = collected.getEverythingByType();

        Set<DeclarationType> heap = new HashSet<>(collected.getEveryThing());
        heap.removeAll(new CollectEveryTypeVisitor(collected.getDeclarations(), true).getEveryThing());

        List<DeclarationType> interfaces = Util.concat(byType.get(InterfaceDeclarationType.class), byType.get(UnnamedObjectType.class));

        for (int i = 0; i < interfaces.size(); i++) {
            DeclarationType one = interfaces.get(i);
            for (int j = 0; j < interfaces.size(); j++) {
                if (i == j) {
                    continue;
                }
                DeclarationType two = interfaces.get(j);
                Evaluation similarity = redundantInterfaceCleaner.evaluteSimilarity(one, two, decsToTS, nativeClasses);
                Score score = similarity.score(true);
                if (score.precision > 0.7 && score.recall > 0.7) {
                    if (score.fMeasure >= 0.85) {
                        combine(one, two, replacements, heap);
                    } else if (score.precision == 1 || score.recall == 1){
                        combine(one, two, replacements, heap);
                    } else if (!hasObject(one) && !hasObject(two)){
                        continue;
                    } else if (hasDynAccess(one) ^/*XOR*/ hasDynAccess(two) && numberOfFields(one) + numberOfFields(two) <= 5 && score.fMeasure < 0.9) { // If only one has dynamic access, I think they should be quite similar before i merge them.
                        continue;
                    } else if (hasObject(one) ^/*XOR*/ hasObject(two) && numberOfFields(one) + numberOfFields(two) <= 3 && score.fMeasure < 0.9) {
                        continue;
                    } else if (hasDynAccess(one) && hasDynAccess(two) && Math.min(numberOfFields(one), numberOfFields(two)) <= 2 && score.fMeasure < 0.9) {
                        continue;
                    } else if (hasDynAccess(one) && !hasDynAccess(two) && numberOfFields(one) > numberOfFields(two) && score.recall >= 0.8) {
                        combine(one, two, replacements, heap);
                    } else if (Math.min(numberOfFields(one), numberOfFields(two)) >= 4 && score.fMeasure >= 0.7) {
                        combine(one, two, replacements, heap);
                    } else if (Math.min(numberOfFields(one), numberOfFields(two)) >= 4 && score.recall >= 0.95) {
                        combine(one, two, replacements, heap);
                    } else if (Math.max(numberOfFields(one), numberOfFields(two)) <= 2 && score.fMeasure <= 0.7) { // Only one of the fields are similar.
                        continue;
                    } else if (Math.max(numberOfFields(one), numberOfFields(two)) <= 2 && score.fMeasure >= 0.8) {
                        combine(one, two, replacements, heap);
                    } else if (Math.max(numberOfFields(one), numberOfFields(two)) <= 5 && score.fMeasure <= 0.8) {
                        continue;
                    } else if (hasObject(one) && hasObject(two) && numberOfFields(two) > numberOfFields(one) && score.precision >= 0.8) {
                        combine(one, two, replacements, heap);
                    } else if (hasObject(one) && hasObject(two) && numberOfFields(one) > numberOfFields(two) && score.recall >= 0.8) {
                        combine(one, two, replacements, heap);
                    } else if (Math.min(numberOfFields(one), numberOfFields(two)) >= 5 && score.fMeasure <= 0.8) {
                        continue;
                    } else {
                        System.out.println("Found something similar");
                    }
                }
            }
        }

        return replacements;
    }

    @Override
    public String getDescription() {
        return "interface == interface";
    }
}
