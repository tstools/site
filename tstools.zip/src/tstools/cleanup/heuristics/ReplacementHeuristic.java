package tstools.cleanup.heuristics;

import com.google.common.collect.Multimap;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.cleanup.CollectEveryTypeVisitor;

/**
 * Created by * on 11-03-2016.
 */
public interface ReplacementHeuristic {
    Multimap<DeclarationType, DeclarationType> findReplacements(CollectEveryTypeVisitor collected);

    String getDescription();
}
