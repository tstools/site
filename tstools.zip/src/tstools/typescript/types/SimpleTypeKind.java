package tstools.typescript.types;

public enum SimpleTypeKind {
    Any,
    String,
    Enum,
    Number,
    Boolean,
    Void,
    Undefined,
    Null
}
