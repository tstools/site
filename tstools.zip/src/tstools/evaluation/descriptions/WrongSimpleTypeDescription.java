package tstools.evaluation.descriptions;

import tstools.typescript.types.SimpleType;
import tstools.typescript.types.Type;

/**
 * Created by * on 09-06-2016.
 */
public class WrongSimpleTypeDescription implements Description {
    private final SimpleType expected;
    private final Type actual;

    public WrongSimpleTypeDescription(SimpleType expected, Type actual) {
        this.expected = expected;
        this.actual = actual;
    }

    public SimpleType getExpected() {
        return expected;
    }

    public Type getActual() {
        return actual;
    }

    @Override
    public <T> T accept(DescriptionVisitor<T> visitor) {
        return visitor.visit(this);
    }

    @Override
    public DescriptionType getType() {
        return DescriptionType.FALSE_NEGATIVE;
    }

    @Override
    public String toString() {
        return "Wrong simple type, was supposed to be: " + expected.getKind().toString() + " was " + actual;
    }
}
