package tstools;

import tstools.paser.AST.BinaryExpression;
import tstools.paser.AST.NodeTransverse;
import tstools.paser.AST.Operator;

/**
 * Created by  *  on 01-12-2015.
 */
public class FindEqualVisitor implements NodeTransverse<Void> {
    public int doubleEqCounter = 0;
    public int trippleEqCounter = 0;

    @Override
    public Void visit(BinaryExpression expression) {
        if (expression.getOperator() == Operator.EQUAL_EQUAL) {
            doubleEqCounter++;
        }
        if (expression.getOperator() == Operator.EQUAL_EQUAL_EQUAL) {
            trippleEqCounter++;
        }
        return NodeTransverse.super.visit(expression);
    }

}
