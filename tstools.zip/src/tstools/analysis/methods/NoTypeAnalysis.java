package tstools.analysis.methods;

import tstools.Options;
import tstools.analysis.*;
import tstools.analysis.methods.mixed.MixedTypeAnalysis;
import tstools.analysis.unionFind.*;
import tstools.declarationReader.DeclarationParser;
import tstools.jsnap.Snap;
import tstools.jsnap.classes.LibraryClass;
import tstools.paser.AST.*;

import java.util.*;

/**
 * Created by
 */
public class NoTypeAnalysis extends MixedTypeAnalysis {
    public NoTypeAnalysis(Map<Snap.Obj, LibraryClass> libraryClasses, Options options, Snap.Obj globalObject, DeclarationParser.NativeClassesMap nativeClasses, boolean upperBoundMethod, Map<AstNode, Set<Snap.Obj>> callsites) {
        super(libraryClasses, options, globalObject, nativeClasses, upperBoundMethod, callsites);
    }

    @Override
    public void applyConstraints(Snap.Obj closure, Map<Snap.Obj, FunctionNode> functionNodes, UnionFindSolver solver, FunctionNode functionNode, HeapValueFactory heapFactory, Map<Identifier, UnionNode> identifierMap) {
        // Do nothing
    }

    @Override
    public void analyse(Snap.Obj closure, Map<Snap.Obj, FunctionNode> functionNodes, UnionFindSolver solver, FunctionNode functionNode, HeapValueFactory heapFactory) {
        if (closure.function.type.equals("unknown")) {
            return;
        }

        applyConstraints(closure, functionNodes, solver, functionNode, heapFactory, new HashMap<>());

    }
}
