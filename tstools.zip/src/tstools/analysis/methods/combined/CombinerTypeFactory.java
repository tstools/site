package tstools.analysis.methods.combined;

import tstools.Options;
import tstools.analysis.TypeAnalysis;
import tstools.analysis.TypeFactory;
import tstools.analysis.declarations.types.CombinationType;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.unionFind.UnionFeature;
import tstools.declarationReader.DeclarationParser;
import tstools.jsnap.Snap;
import tstools.jsnap.classes.LibraryClass;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A weird class, that makes sure that both the result of the Mixed analysis and the Subset analysis is sent to a single typeFactory.
 */
public class CombinerTypeFactory extends TypeFactory {
    public CombinerTypeFactory(Snap.Obj globalObject, Map<Snap.Obj, LibraryClass> libraryClasses, Options options, DeclarationParser.NativeClassesMap nativeClasses, TypeAnalysis typeAnalysis) {
        super(globalObject, libraryClasses, options, nativeClasses, typeAnalysis);
    }

    private Map<Snap.Obj, List<UnionFeature>> calledRegisterFunction = new HashMap<>();
    @Override
    public void registerFunction(Snap.Obj closure, List<UnionFeature> features) {
        if (calledRegisterFunction.containsKey(closure)) {
            List<UnionFeature> result = new ArrayList<>();
            result.addAll(calledRegisterFunction.get(closure));
            result.addAll(features);
            super.registerFunction(closure, result);
            return;
        }
        calledRegisterFunction.put(closure, features);
    }


    private Map<Snap.Obj, DeclarationType> calledResolvedFunctions = new HashMap<>();
    @Override
    public void putResolvedFunctionType(Snap.Obj closure, DeclarationType type) {
        if (calledResolvedFunctions.containsKey(closure)) {
            DeclarationType existingType = calledResolvedFunctions.get(closure);
            CombinationType resultingType = new CombinationType(super.typeReducer, existingType, type);
            super.putResolvedFunctionType(closure, resultingType);
            return;
        }
        calledResolvedFunctions.put(closure, type);
    }

    boolean resolveCalledOnce = false;
    @Override
    public void resolveClassTypes() {
        if (resolveCalledOnce) {
            super.resolveClassTypes();
        }
        resolveCalledOnce = true;
    }
}
