package tstools.analysis.methods.pureSubsets;

import tstools.Options;
import tstools.analysis.HeapValueFactory;
import tstools.analysis.methods.mixed.MixedTypeAnalysis;
import tstools.analysis.unionFind.FunctionNode;
import tstools.analysis.unionFind.UnionFindSolver;
import tstools.analysis.unionFind.UnionNode;
import tstools.declarationReader.DeclarationParser;
import tstools.jsnap.Snap;
import tstools.jsnap.classes.LibraryClass;
import tstools.paser.AST.AstNode;
import tstools.paser.AST.Identifier;

import java.util.Map;
import java.util.Set;

/**
 * Created by * on 05-02-2016.
 */
public class PureSubsetsTypeAnalysis extends MixedTypeAnalysis {
    public PureSubsetsTypeAnalysis(Map<Snap.Obj, LibraryClass> libraryClasses, Options options, Snap.Obj globalObject, DeclarationParser.NativeClassesMap nativeClasses, Map<AstNode, Set<Snap.Obj>> callsites) {
        super(libraryClasses, options, globalObject, nativeClasses, false, callsites);
    }

    @Override
    public void applyConstraints(Snap.Obj closure, Map<Snap.Obj, FunctionNode> functionNodes, UnionFindSolver solver, FunctionNode functionNode, HeapValueFactory heapFactory, Map<Identifier, UnionNode> identifierMap) {
        new PureSubsetsConstraintVisitor(closure, solver, identifierMap, functionNode, functionNodes, heapFactory, this, this.nativeTypeFactory, callsites).visit(closure.function.astNode);
    }
}
