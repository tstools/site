package tstools.analysis.methods.contextSensitive.combined;

import tstools.Options;
import tstools.analysis.HeapValueFactory;
import tstools.analysis.TypeAnalysis;
import tstools.analysis.TypeFactory;
import tstools.analysis.methods.contextSensitive.mixed.MixedContextSensitiveTypeAnalysis;
import tstools.analysis.methods.contextSensitive.pureSubsets.PureSubsetsContextSensitiveTypeAnalysis;
import tstools.analysis.unionFind.FunctionNode;
import tstools.analysis.unionFind.IncludeNode;
import tstools.analysis.unionFind.UnionFindSolver;
import tstools.declarationReader.DeclarationParser;
import tstools.jsnap.Snap;
import tstools.jsnap.classes.LibraryClass;
import tstools.paser.AST.AstNode;

import java.util.Map;
import java.util.Set;

/**
 * Created by * on 24-02-2016.
 */
@SuppressWarnings("Duplicates")
public class CombinedContextSensitiveTypeAnalysis implements TypeAnalysis {
    private final MixedContextSensitiveTypeAnalysis mixed;
    private final PureSubsetsContextSensitiveTypeAnalysis subset;
    private final TypeFactory typeFactory;

    public CombinedContextSensitiveTypeAnalysis(Map<Snap.Obj, LibraryClass> libraryClasses, Options options, Snap.Obj globalObject, DeclarationParser.NativeClassesMap nativeClasses, boolean upperBoundMethod, Map<AstNode, Set<Snap.Obj>> callsites) {
        mixed = new MixedContextSensitiveTypeAnalysis(libraryClasses, options, globalObject, nativeClasses, upperBoundMethod, callsites);
        subset = new PureSubsetsContextSensitiveTypeAnalysis(libraryClasses, options, globalObject, nativeClasses, callsites);

        typeFactory = new CombinerTypeFactory(globalObject, libraryClasses, options, nativeClasses, this);
        mixed.typeFactory = typeFactory;
        subset.typeFactory = typeFactory;
    }

    @Override
    public void analyseFunctions() {
        System.out.println("Running combined, mixed");
        mixed.analyseFunctions();
        System.out.println("Running combined, subsets");
        subset.analyseFunctions();
    }

    @Override
    public TypeFactory getTypeFactory() {
        return typeFactory;
    }

    @Override
    public Options getOptions() {
        return mixed.getOptions();
    }

    @Override
    public Map<Snap.Obj, LibraryClass> getLibraryClasses() {
        return mixed.getLibraryClasses();
    }

    @Override
    public DeclarationParser.NativeClassesMap getNativeClasses() {
        return mixed.getNativeClasses();
    }

    // Just used for getters and setters, not that important.
    @Override
    public FunctionNode getFunctionNode(Snap.Obj closure) {
        FunctionNode mixed = this.mixed.getFunctionNode(closure);
        FunctionNode subset = this.subset.getFunctionNode(closure);
        if (mixed == null && subset == null) {
            return null;
        }
        if (mixed == null) {
            return subset;
        }
        if (subset == null) {
            return mixed;
        }
        UnionFindSolver solver = this.mixed.solver;
        FunctionNode result = FunctionNode.create(closure, solver);
        solver.union(result.thisNode, new IncludeNode(solver, mixed.thisNode, subset.thisNode));
        solver.union(result.returnNode, new IncludeNode(solver, mixed.returnNode, subset.returnNode));
        for (int i = 0; i < result.arguments.size(); i++) {
            solver.union(result.arguments.get(i), new IncludeNode(solver, mixed.arguments.get(i), subset.arguments.get(i)));
        }
        return result;
    }

    @Override
    public HeapValueFactory getHeapFactory() {
        return mixed.getHeapFactory();
    }

    @Override
    public UnionFindSolver getSolver() {
        return mixed.solver;
    }

    @Override
    public Snap.Obj getGlobalObject() {
        return mixed.getGlobalObject();
    }
}
