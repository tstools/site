package tstools.analysis;

import tstools.Options;
import tstools.analysis.unionFind.FunctionNode;
import tstools.analysis.unionFind.UnionFindSolver;
import tstools.declarationReader.DeclarationParser;
import tstools.jsnap.Snap;
import tstools.jsnap.classes.LibraryClass;

import java.util.Map;

/**
 * Created by * on 05-02-2016.
 */
public interface TypeAnalysis {
    void analyseFunctions();

    TypeFactory getTypeFactory();

    Options getOptions();

    Map<Snap.Obj, LibraryClass> getLibraryClasses();

    DeclarationParser.NativeClassesMap getNativeClasses();

    FunctionNode getFunctionNode(Snap.Obj closure);

    HeapValueFactory getHeapFactory();

    UnionFindSolver getSolver();

    Snap.Obj getGlobalObject();
}
