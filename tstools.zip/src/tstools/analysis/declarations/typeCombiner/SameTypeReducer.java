package tstools.analysis.declarations.typeCombiner;

import tstools.analysis.declarations.types.DeclarationType;

import java.util.List;
import java.util.Map;

/**
 * Created by  *  on 23-11-2015.
 */
public abstract class SameTypeReducer<T extends DeclarationType> extends SingleTypeReducer<T, T> {
    protected SameTypeReducer(Map<DeclarationType, List<DeclarationType>> originals) {
        super(originals);
    }

    @Override
    public final Class<T> getAClass() {
        return getTheClass();
    }

    @Override
    public final Class<T> getBClass() {
        return getTheClass();
    }

    public abstract Class<T> getTheClass();
}
