package tstools.analysis.declarations.typeCombiner;

import tstools.analysis.declarations.types.DeclarationType;

/**
 * Created by  *  on 17-10-2015.
 */
public interface SingleTypeReducerInterface<A extends DeclarationType, B extends DeclarationType> {
    Class<A> getAClass();
    Class<B> getBClass();
    DeclarationType reduce(A a, B b);
}
