package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import tstools.analysis.declarations.typeCombiner.SameTypeReducer;
import tstools.analysis.declarations.types.CombinationType;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.UnnamedObjectType;
import tstools.analysis.declarations.typeCombiner.TypeReducer;
import tstools.util.Util;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by  *  on 18-10-2015.
 */
public class UnnamedObjectReducer extends SameTypeReducer<UnnamedObjectType> {
    private final TypeReducer combiner;

    public UnnamedObjectReducer(TypeReducer combiner, Map<DeclarationType, List<DeclarationType>> originals) {
        super(originals);
        this.combiner = combiner;
    }

    @Override
    public Class<UnnamedObjectType> getTheClass() {
        return UnnamedObjectType.class;
    }

    @Override
    public UnnamedObjectType reduceIt(UnnamedObjectType one, UnnamedObjectType two) {
        Multimap<String, DeclarationType> declarations = ArrayListMultimap.create();
        for (Map.Entry<String, DeclarationType> entry : one.getDeclarations().entrySet()) {
            declarations.put(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, DeclarationType> entry : two.getDeclarations().entrySet()) {
            declarations.put(entry.getKey(), entry.getValue());
        }

        Map<String, DeclarationType> result = new HashMap<>();
        for (Map.Entry<String, Collection<DeclarationType>> entry : declarations.asMap().entrySet()) {
            Collection<DeclarationType> types = entry.getValue();
            if (types.size() == 0) {
                throw new RuntimeException();
            } else if (types.size() == 1) {
                result.put(entry.getKey(), types.iterator().next());
            } else {
                result.put(entry.getKey(), new CombinationType(combiner, types));
            }
        }

        return new UnnamedObjectType(result, Util.concatSet(one.getNames(), two.getNames()));
    }
}
