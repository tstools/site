package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import tstools.analysis.declarations.typeCombiner.SingleTypeReducerInterface;
import tstools.analysis.declarations.types.DeclarationType;

/**
 * Created by  *  on 05-11-2015.
 */
public class CantReduceReducer<A extends DeclarationType, B extends DeclarationType> implements SingleTypeReducerInterface<A, B> {
    private final Class<A> aClass;
    private final Class<B> bClass;

    public CantReduceReducer(Class<A> aClass, Class<B> bClass) {
        this.aClass = aClass;
        this.bClass = bClass;
    }

    @Override
    public Class<A> getAClass() {
        return aClass;
    }

    @Override
    public Class<B> getBClass() {
        return bClass;
    }

    @Override
    public DeclarationType reduce(A a, B b) {
        return null;
    }
}
