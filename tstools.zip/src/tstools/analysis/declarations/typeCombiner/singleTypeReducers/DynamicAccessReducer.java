package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import tstools.analysis.declarations.typeCombiner.SameTypeReducer;
import tstools.analysis.declarations.typeCombiner.TypeReducer;
import tstools.analysis.declarations.types.CombinationType;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.DynamicAccessType;
import tstools.util.Util;

import java.util.List;
import java.util.Map;

/**
 * Created by  *  on 05-11-2015.
 */
public class DynamicAccessReducer extends SameTypeReducer<DynamicAccessType> {
    private final TypeReducer combiner;

    public DynamicAccessReducer(TypeReducer combiner, Map<DeclarationType, List<DeclarationType>> originals) {
        super(originals);
        this.combiner = combiner;
    }

    @Override
    public Class<DynamicAccessType> getTheClass() {
        return DynamicAccessType.class;
    }

    @Override
    public DynamicAccessType reduceIt(DynamicAccessType one, DynamicAccessType two) {
        CombinationType returnType = new CombinationType(combiner, one.getReturnType(), two.getReturnType());
        CombinationType lookupType = new CombinationType(combiner, one.getLookupType(), two.getLookupType());
        return new DynamicAccessType(lookupType, returnType, Util.concatSet(one.getNames(), two.getNames()));
    }
}
