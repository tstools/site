package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import tstools.analysis.declarations.typeCombiner.SingleTypeReducerInterface;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.PrimitiveDeclarationType;
import tstools.analysis.declarations.types.UnnamedObjectType;
import tstools.jsnap.Snap;

/**
 * Created by  *  on 17-10-2015.
 */
public class PrimitiveObjectReducer implements SingleTypeReducerInterface<PrimitiveDeclarationType, UnnamedObjectType> {
    private final Snap.Obj globalObject;

    public PrimitiveObjectReducer(Snap.Obj globalObject) {
        this.globalObject = globalObject;
    }

    @Override
    public Class<PrimitiveDeclarationType> getAClass() {
        return PrimitiveDeclarationType.class;
    }

    @Override
    public Class<UnnamedObjectType> getBClass() {
        return UnnamedObjectType.class;
    }

    @Override
    public DeclarationType reduce(PrimitiveDeclarationType primitive, UnnamedObjectType object) {
        if (objectPropsMatchPrimitivePrototypes(primitive, object)) {
            return primitive;
        } else {
            return null;
        }
    }

    private boolean objectPropsMatchPrimitivePrototypes(PrimitiveDeclarationType primitive, UnnamedObjectType object) {
        return object.getDeclarations().keySet().stream().allMatch(key -> {
            boolean matchObject = objectFieldMatchPrototypeOf(this.globalObject.getProperty("Object").value, key);
            boolean matchPrimitive;
            switch (primitive.getType()) {
                case NUMBER:
                    matchPrimitive = objectFieldMatchPrototypeOf(this.globalObject.getProperty("Number").value, key); break;
                case BOOLEAN:
                    matchPrimitive = objectFieldMatchPrototypeOf(this.globalObject.getProperty("Boolean").value, key); break;
                case STRING:
                    matchPrimitive = objectFieldMatchPrototypeOf(this.globalObject.getProperty("String").value, key); break;
                case STRING_OR_NUMBER:
                    matchPrimitive = objectFieldMatchPrototypeOf(this.globalObject.getProperty("String").value, key)
                                  || objectFieldMatchPrototypeOf(this.globalObject.getProperty("Number").value, key);
                    break;
                case VOID:
                case NON_VOID:
                case ANY:
                    throw new RuntimeException("Not supposed to be any any, void or undefined at this point.");
                default:
                    throw new UnsupportedOperationException("Don't know this " + primitive + ", when checking if the object accesses match the primitive");
            }
            return matchObject || matchPrimitive;
        });
    }

    static boolean objectFieldMatchPrototypeOf(Snap.Value value, String key) {
        if (!(value instanceof Snap.Obj)) {
            throw new RuntimeException();
        }
        Snap.Obj prototype = (Snap.Obj) ((Snap.Obj) value).getProperty("prototype").value;
        return prototype.getProperty(key) != null;
    }
}
