package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import tstools.analysis.declarations.typeCombiner.SingleTypeReducerInterface;
import tstools.analysis.declarations.types.ClassType;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.FunctionType;
import tstools.analysis.declarations.typeCombiner.TypeReducer;

/**
 * Created by  *  on 18-10-2015.
 */
public class FunctionClassReducer implements SingleTypeReducerInterface<FunctionType, ClassType> {
    private final TypeReducer combiner;

    public FunctionClassReducer(TypeReducer combiner) {
        this.combiner = combiner;
    }

    @Override
    public Class<FunctionType> getAClass() {
        return FunctionType.class;
    }

    @Override
    public Class<ClassType> getBClass() {
        return ClassType.class;
    }

    @Override
    public DeclarationType reduce(FunctionType functionType, ClassType classType) {
        // Same reasoning as in ClassObjectReducer.
        return classType;
    }
}
