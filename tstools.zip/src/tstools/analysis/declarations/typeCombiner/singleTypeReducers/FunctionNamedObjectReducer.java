package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import tstools.typescript.types.GenericType;
import tstools.typescript.types.InterfaceType;
import tstools.typescript.types.Type;
import tstools.analysis.declarations.typeCombiner.SingleTypeReducer;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.FunctionType;
import tstools.analysis.declarations.types.NamedObjectType;
import tstools.jsnap.Snap;

import java.util.List;
import java.util.Map;

import static tstools.declarationReader.DeclarationParser.NativeClassesMap;

/**
 * Created by  *  on 19-11-2015.
 */
public class FunctionNamedObjectReducer extends SingleTypeReducer<FunctionType, NamedObjectType> {
    private NativeClassesMap nativeClasses;

    public FunctionNamedObjectReducer(NativeClassesMap nativeClasses, Map<DeclarationType, List<DeclarationType>> originals) {
        super(originals);
        this.nativeClasses = nativeClasses;
    }

    @Override
    public Class<FunctionType> getAClass() {
        return FunctionType.class;
    }

    @Override
    public Class<NamedObjectType> getBClass() {
        return NamedObjectType.class;
    }

    @Override
    public DeclarationType reduceIt(FunctionType function, NamedObjectType named) {
        Snap.Obj obj = this.nativeClasses.objectFromName(named.getName());
        if (obj != null && obj.function != null) {
            return named; // Lot of assuming here,
        }
        Type type = this.nativeClasses.typeFromName(named.getName());
        if (type instanceof GenericType) {
            type = ((GenericType) type).toInterface();
        }
        if (type instanceof InterfaceType) {
            InterfaceType inter = (InterfaceType) type;
            if (!inter.getDeclaredCallSignatures().isEmpty() || !inter.getDeclaredConstructSignatures().isEmpty()) {
                return named;
            }
        }
        return null;
    }
}
