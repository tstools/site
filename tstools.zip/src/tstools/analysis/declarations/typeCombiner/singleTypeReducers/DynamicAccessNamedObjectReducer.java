package tstools.analysis.declarations.typeCombiner.singleTypeReducers;

import tstools.typescript.types.GenericType;
import tstools.typescript.types.InterfaceType;
import tstools.typescript.types.Type;
import tstools.analysis.declarations.typeCombiner.SingleTypeReducer;
import tstools.analysis.declarations.typeCombiner.TypeReducer;
import tstools.analysis.declarations.types.CombinationType;
import tstools.analysis.declarations.types.DeclarationType;
import tstools.analysis.declarations.types.DynamicAccessType;
import tstools.analysis.declarations.types.NamedObjectType;
import tstools.declarationReader.DeclarationParser;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Created by  *  on 11-11-2015.
 */
public class DynamicAccessNamedObjectReducer extends SingleTypeReducer<DynamicAccessType, NamedObjectType> {
    private final DeclarationParser.NativeClassesMap nativeClasses;
    private final TypeReducer combiner;

    public DynamicAccessNamedObjectReducer(DeclarationParser.NativeClassesMap nativeClasses, TypeReducer combiner, Map<DeclarationType, List<DeclarationType>> originals) {
        super(originals);
        this.nativeClasses = nativeClasses;
        this.combiner = combiner;
    }

    @Override
    public Class<DynamicAccessType> getAClass() {
        return DynamicAccessType.class;
    }

    @Override
    public Class<NamedObjectType> getBClass() {
        return NamedObjectType.class;
    }

    @Override
    public DeclarationType reduceIt(DynamicAccessType dynamic, NamedObjectType named) {
        String name = named.getName();
        if (name.equals("Array")) {
            CombinationType arrayType = new CombinationType(combiner, dynamic.getReturnType());
            if (named.getIndexType() != null) {
                arrayType.addType(named.getIndexType());
            }
            return new NamedObjectType("Array", named.isBaseType, arrayType);
        }
        Type type = nativeClasses.typeFromName(name);
        if (type == null) {
            return null;
        }
        if (nameHasIndexer(type)) return named;
        if (named.getKnownSubTypes().stream().map(nativeClasses::typeFromName).filter(Objects::nonNull).anyMatch(this::nameHasIndexer)) {
            return named;
        }
        return null;
    }

    private boolean nameHasIndexer(Type type) {
        if (type instanceof GenericType) {
            type = ((GenericType) type).toInterface();
        }
        if (type instanceof InterfaceType) {
            InterfaceType inter = (InterfaceType) type;
            if (inter.getDeclaredNumberIndexType() != null || inter.getDeclaredStringIndexType() != null) {
                return true;
            }
        }
        return false;
    }
}
