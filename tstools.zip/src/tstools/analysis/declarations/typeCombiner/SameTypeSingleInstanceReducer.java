package tstools.analysis.declarations.typeCombiner;

import tstools.analysis.declarations.types.DeclarationType;

/**
 * Created by * on 12-02-2016.
 */
public interface SameTypeSingleInstanceReducer<T extends DeclarationType> {
    DeclarationType reduce(T declarationType);

    Class<T> getTheClass();
}
