package tstools.analysis.declarations.types;

import java.util.Set;

/**
 * Created by  *  on 18-09-2015.
 */
public class ClassInstanceType extends DeclarationType {
    public DeclarationType clazz;

    public ClassInstanceType(DeclarationType clazz, Set<String> names) {
        super(names);
        if (clazz == null) {
            throw new NullPointerException();
        }
        if (!(clazz instanceof UnresolvedDeclarationType) && !(clazz instanceof ClassType)) {
            throw new RuntimeException();
        }
        this.clazz = clazz;
    }

    // Casting because of UnresolvedDeclarationType
    public ClassType getClazz() {
        return (ClassType) clazz.resolve();
    }

    public void setClazz(DeclarationType clazz) {
        this.clazz = clazz;
    }

    @Override
    public <T> T accept(DeclarationTypeVisitor<T> visitor) {
        return visitor.visit(this);
    }

    @Override
    public <T, A> T accept(DeclarationTypeVisitorWithArgument<T, A> visitor, A argument) {
        return visitor.visit(this, argument);
    }
}
