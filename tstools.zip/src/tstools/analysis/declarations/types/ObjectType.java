package tstools.analysis.declarations.types;

import java.util.Set;

/**
 * Created by  *  on 06-09-2015.
 */
public abstract class ObjectType extends DeclarationType {

    public ObjectType(Set<String> names) {
        super(names);
    }
}
