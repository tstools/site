package tstools.analysis.declarations.types;

/**
 * Created by  *  on 04-09-2015.
 */
public interface DeclarationTypeVisitor<T> {
    T visit(FunctionType functionType);

    T visit(PrimitiveDeclarationType primitive);

    T visit(UnnamedObjectType objectType);

    T visit(InterfaceDeclarationType interfaceType);

    T visit(UnionDeclarationType union);

    T visit(NamedObjectType namedObjectType);

    T visit(ClassType classType);

    T visit(ClassInstanceType instanceType);
}
