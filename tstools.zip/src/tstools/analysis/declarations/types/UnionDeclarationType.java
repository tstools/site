package tstools.analysis.declarations.types;

import tstools.util.Util;

import java.util.*;

/**
 * Created by  *  on 09-09-2015.
 */
public class UnionDeclarationType extends DeclarationType {
    private List<DeclarationType> types;

    public UnionDeclarationType(DeclarationType... types) {
        super(Arrays.asList(types).stream().map(DeclarationType::getNames).reduce(new HashSet<>(), Util::reduceSet));
        if (types.length == 0) {
            throw new IllegalArgumentException();
        }

        // This does 2 things: filters out nulls, and flattens 1-level nested UnionDeclarations.
        for (DeclarationType type : types) {
            if (type == null) {
                throw new RuntimeException();
            }
        }

        this.types = Arrays.asList(types).stream().filter(type -> type != null).reduce(new ArrayList<>(), (acc, dec) -> {
            unfoldDeclaration(acc, dec);
            return acc;
        }, Util::reduceList);
    }

    private void unfoldDeclaration(ArrayList<DeclarationType> acc, DeclarationType type) {
        if (type instanceof UnionDeclarationType) {
            List<DeclarationType> types = ((UnionDeclarationType) type).types;
            for (DeclarationType subType : types) {
                unfoldDeclaration(acc, subType);
            }

        } else {
            acc.add(type);
        }
    }

    public UnionDeclarationType(Collection<? extends DeclarationType> types) {
        this(types.toArray(new DeclarationType[types.size()]));
    }

    public List<DeclarationType> getTypes() {
        return types;
    }

    public void setTypes(List<DeclarationType> types) {
        this.types = types;
    }

    @Override
    public <T> T accept(DeclarationTypeVisitor<T> visitor) {
        return visitor.visit(this);
    }

    @Override
    public <T, A> T accept(DeclarationTypeVisitorWithArgument<T, A> visitor, A argument) {
        return visitor.visit(this, argument);
    }
}
