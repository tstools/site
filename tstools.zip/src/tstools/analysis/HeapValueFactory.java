package tstools.analysis;

import tstools.analysis.unionFind.PrimitiveNode;
import tstools.analysis.unionFind.UnionNode;
import tstools.jsnap.Snap;

/**
 * Created by
 */
public interface HeapValueFactory {
    UnionNode fromValue(Snap.Value value);

    PrimitiveNode.Factory getPrimitivesFactory();

    UnionNode fromProperty(Snap.Property property);
}
