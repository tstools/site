/**
 * Created by hamid on 12/2/15.
 */
function f() {
    return g();
}
function g() {
    a = 400;
    z = 8000;
    return a*z;
}