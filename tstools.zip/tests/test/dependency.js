
// Basically impossible to analyse.
function getRandomInt(seed) {
    return arguments[0];
}

var myValue = {
    num: 123,
    str: "stirng",
    bool: 123
};
