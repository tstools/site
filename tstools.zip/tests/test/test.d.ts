declare var bool: boolean;

declare var str: string;

declare var num: number;

declare var random : () => number;

declare function myDistinctName(string: string): number;