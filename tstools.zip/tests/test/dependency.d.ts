
// Basically impossible to analyse, but the type makes sense...
declare function getRandomInt(seed : number) : number;

interface myInterface {
    num: number,
    str: string,
    bool: boolean
}

declare var myValue : myInterface;
