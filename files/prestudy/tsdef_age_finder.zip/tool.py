# TODO
# foreach timestamp
## Checkout DefinitelyTyped at date `timestamp` 
## foreach name 
### checkout repo at date `timestamp`
### Find defTyped d.ts. version number
### Find repos newest version (discard beta's)
### calculate diff in time
import json
import git
import os
from pprint import pprint
import githelper
import typedesc_helper
from excel_helper import save_to_excel


#Global vars
config = 0
definitely_typed_repo = 0


def load_config_file():
    with open('config.json') as config_file:
        global config
        config = json.load(config_file)


# Returns list of repos
# Clone the repos if needed.
def get_git_repos():
    global config
    for project in config['projects']:
        repo_path = os.path.join(os.getcwd(), 'repos', project['name'])
        if not os.path.exists(repo_path):
            print("{0} is missing, cloning to {1}".format(project['name'], repo_path))
            repo = git.Repo.clone_from(project['github'], repo_path)
        else:
            repo = git.Repo(repo_path)
        project['repo'] = repo 


def find_dts_version_number(project, timestamp):
    type_desc_file_path = typedesc_helper.get_typedesc_file_path(project['name']) 
    if type_desc_file_path is None:
        raise Exception("Could not find type description file"\
                        .format(project['name'], timestamp))
    type_desc_version_nr = typedesc_helper \
                           .get_typedesc_version_number(project['name'], type_desc_file_path)
    if type_desc_version_nr is None: 
        raise Exception("Unable to determine version number from type description file"\
                .format(project['name'], timestamp))
    return type_desc_version_nr


def find_tag_for_version_number(project, version_nr):
    tag = githelper.find_tag_with_version_number(project['repo'], version_nr)
    if tag is None:
        raise Exception("Unable to find tag for version number"\
                .format(type_desc_version_nr))
    return tag


def find_latest_tagged_commit(project, timestamp):
    latest_tag = githelper.get_latest_tag(project['repo'], timestamp)
    if latest_tag is None:
        raise Exception("Unable to find latest tagged commit")
    return latest_tag


def find_time_diff_measures():
    global definitely_typed_repo
    result = {} 
    timestamps = config['timestamps'] 
    for timestamp in reversed(timestamps): # when searching for commits, git can only find relative to the current commit. Therefore we always need to search for an earlier commit, therefore it starts with the latest timestamp. 
        commit_before_ts = githelper.get_commit_before_timestamp(definitely_typed_repo, timestamp)
        if commit_before_ts is None:
            raise Exception("No commit before timestamp: {} in the Definitely Typed repository"\
                            .format(timestamp)) 
        definitely_typed_repo.git.checkout(commit_before_ts)
    
        res_for_timestamp = [] 
        result[timestamp] = res_for_timestamp
        for project in config['projects']:
            print("Finding for project " + project["name"] + " timestamp: " + str(timestamp))
            try:
                measure = find_time_difference_data(project, timestamp)
                res_for_timestamp.append(measure)
            except Exception as e:
                print("Had error: " + str(e) + " for project " + project["name"] + " timestamp: " + str(timestamp))
                res_for_timestamp.append({'error' : str(e), 'project' : project['name']})
    return result


def find_time_difference_data(project, timestamp):
    dts_version_number = find_dts_version_number(project, timestamp) 
    dts_version_tag = find_tag_for_version_number(project, dts_version_number)
    latest_tag = find_latest_tagged_commit(project, timestamp) 
    latest_tag_timestamp = githelper.to_timestamp(latest_tag.commit.committed_datetime)
    dts_version_timestamp = githelper.to_timestamp(dts_version_tag.commit.committed_datetime)
    timediff = latest_tag_timestamp - dts_version_timestamp
    if timediff < 0: 
       timediff = 0
    result = {'dts_version_number' : str(dts_version_tag), 'js_version_number' : str(latest_tag),
              'timestamp' : timestamp, 'timediff' : timediff, 'project' : project['name'],
              'error' : None, 'latest_tag_timestamp' : latest_tag_timestamp, 
              'dts_version_timestamp' : dts_version_timestamp}
    return result 


# Some preliminary checks
def pre_execution_checks():
    clone_definitely_typed()


def clone_definitely_typed():
    definitely_typed_path = os.path.join(os.getcwd(), 'DefinitelyTyped')
    if not os.path.exists(definitely_typed_path):
        print("DefinitelyTyped is missing, cloning to {0}".format(definitely_typed_path))
        global config, definitely_typed_repo
        definitely_typed_repo = git.Repo.clone_from(config['DefinitelyTypedRepo']
                , definitely_typed_path)
    else:
        definitely_typed_repo = git.Repo(definitely_typed_path)


def main():
    load_config_file()
    pre_execution_checks()
    get_git_repos()
    definitely_typed_repo.git.checkout("master") # Making sure that every timestamp is correct
    r = find_time_diff_measures()
    #pprint(r)
    save_to_excel(r)

main()
