import calendar
import re

#Returns the first commit in repo after timestamp
def get_commit_after_timestamp(repo, timestamp):
    commits_reversed = list(repo.iter_commits())[::-1]
    return next(filter(lambda commit:
        to_timestamp(commit.committed_datetime) >= timestamp
        , commits_reversed), None)


#Returns the first commit in repo before timestamp
def get_commit_before_timestamp(repo, timestamp):
    commits = repo.iter_commits()
    return next(filter(lambda commit:
        to_timestamp(commit.committed_datetime) <= timestamp
        , commits), None)


# Returns the latest tag.
# Discards tags containing the strings 'beta', 'alpha' or 'rc'
# and tags newer than timestamp if set
def get_latest_tag(repo, timestamp=None):
   tags = reversed(sorted(repo.tags, key=time_from_tag))
   for tag in tags:
       if should_filter(tag, timestamp):
          continue
       else:
          return tag
   return None

def time_from_tag(tag): 
    return to_timestamp(tag.commit.committed_datetime)

# Returns the newest tag with a tag-name that contains version_number
def find_tag_with_version_number(repo, version_number):
    tags = repo.tags
    regexp = re.compile("({0})".format(version_number), re.IGNORECASE)
    #Filter regexp
    matching_tags = filter(lambda tag:
        re.search(regexp, str(tag)) is not None
        , tags)
    
    latest_datetime = 0 
    latest = None
    for tag in matching_tags:
        if tag.commit.committed_date > latest_datetime:
            latest_datetime = tag.commit.committed_date
            latest = tag
    return latest 


# Returns True if the tag name contains 'beta', 'alpha' or 'rc'
# and the tag is newer than timestamp_max
def should_filter(tag, timestamp_max):
    regexp = re.compile("((alpha)|(beta)|(rc))", re.IGNORECASE)
    res = re.search(regexp, str(tag))
    filtr = False 
    if res is not None:
        filtr = True
    if timestamp_max is not None:
        if to_timestamp(tag.commit.committed_datetime) > timestamp_max:
            filtr = True
    return filtr


def to_timestamp(datetime):
    return calendar.timegm(datetime.timetuple())
