from openpyxl import Workbook
from datetime import datetime

def setup_sheet(sheet, title):
    sheet.title = title 
    sheet.append(['Timestamp', 'Date', 'Project', 'Error',
                  'js version', 'js timestamp', 'd.ts. version',
                  'dts timestamp', 'Timediff', '% of init'])
    sheet.column_dimensions["B"].width = 16 


def insert_data_for_timestamp(sheet, timestamp, measures):
    rows_to_merge = len(measures)
    last_row_before = sheet.max_row
    for measure in measures:
        if measure['error'] is None:
            sheet.append(["", "", measure['project'], measure['error'],
                          measure['js_version_number'], measure['latest_tag_timestamp'],
                          measure['dts_version_number'], measure['dts_version_timestamp'],
                          measure['timediff']]) 
        else:
            sheet.append(["", "", measure['project'], measure['error']])
    last_row_after = sheet.max_row
    sheet.merge_cells(start_row=last_row_before + 1, end_row=last_row_after,
                      start_column=1, end_column=1)
    sheet.merge_cells(start_row=last_row_before + 1, end_row=last_row_after,
                      start_column=2, end_column=2)
    sheet.cell(row=last_row_before + 1, column=1).value = str(timestamp) 
    sheet.cell(row=last_row_before + 1, column=2).value\
        = datetime.fromtimestamp(timestamp) 


def insert_data(sheet, measures):
    timestamps = list(measures.keys())
    timestamps.sort()
    for timestamp in timestamps:
        insert_data_for_timestamp(sheet, timestamp, measures[timestamp])

def insert_growth_values_for_timestamp(sheet, timestamp, measures_for_timestamp, 
                                       timestamp_group, growth_column):
    timediff_column = growth_column - 1
    avg_growth_column = growth_column + 1
    sum_growth_column = growth_column + 2
    months_growth_column = growth_column + 3
    measures_per_timestamp = len(measures_for_timestamp)
    start_row = measures_per_timestamp * (timestamp_group - 1) + 2
    end_row = start_row + measures_per_timestamp - 1
    growth_sum = 0
    count = 0
    growth_sum_absolute = 0;
    for row in range (start_row, end_row + 1):
        init_timediff = sheet.cell(row = row - start_row + 2, column = timediff_column)
        current_timediff = sheet.cell(row = row, column = timediff_column) 
        if init_timediff.value is None or current_timediff.value is None:
            #If None, then probably that measurement resulted in an error
            continue
        else:
            growth_sum_absolute += current_timediff.value
            
            if init_timediff.value == 0:
                growth = 1
            else:
                growth = current_timediff.value / init_timediff.value
            
            growth_cell = sheet.cell(row = row, column = growth_column)
            growth_cell.value = growth
            growth_cell.number_format = '.0%'
            growth_sum += growth
            count += 1
    if count == 0:
        count = 1
    avg = growth_sum / count 
    avg_cell = sheet.cell(row = start_row, column = avg_growth_column)
    avg_cell.value = avg
    avg_cell.number_format = '.0%'
    sheet.merge_cells(start_row=start_row, end_row=end_row,
                      start_column=avg_growth_column, end_column=avg_growth_column)
                      
    sum_cell = sheet.cell(row = start_row, column = sum_growth_column)
    sum_cell.value = growth_sum_absolute
    sheet.merge_cells(start_row=start_row, end_row=end_row,
                      start_column=sum_growth_column, end_column=sum_growth_column)
    
    month_cell = sheet.cell(row = start_row, column = months_growth_column)
    month_cell.value = growth_sum_absolute / (2628000 * count) # There is 2628000 seconds in a month
    sheet.merge_cells(start_row=start_row, end_row=end_row,
                      start_column=months_growth_column, end_column=months_growth_column)


def insert_growth_measures(sheet, measures):
    growth_col = sheet.max_column 
    measures_per_timestamp = len(next(iter(measures.values())))
    timestamps = sorted(list(measures.keys()))
    #timestamps.pop(0)
    timestamp_group = 1
    for timestamp in timestamps:
        insert_growth_values_for_timestamp(sheet, timestamp, measures[timestamp], 
                                           timestamp_group, growth_col)
        timestamp_group += 1
        

def save_to_excel(measures):
    title = "Measurements {0}".format(datetime.now().date())
    wb = Workbook()
    sheet = wb.active
    setup_sheet(sheet, title)
    insert_data(sheet, measures)
    insert_growth_measures(sheet, measures) 
    wb.save("{0}.xlsx".format(title))
    
