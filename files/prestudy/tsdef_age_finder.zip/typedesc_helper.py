import os
import re

# Retuns the path of the typedesc file if exists, None otherwise
# Assummes that the project folder in the DefinitelyTyped repo is named project_name[js]
# and that the file is names project_name.d.ts 
def get_typedesc_file_path (project_name):
    typedesc_file_name = "{0}.d.ts".format(project_name)
    typedesc_file_path = os.path.join(os.getcwd(),
            "DefinitelyTyped",
            project_name,
            typedesc_file_name)
    if os.path.exists(typedesc_file_path):
        return typedesc_file_path 

    typedesc_file_path = os.path.join(os.getcwd(),
            "DefinitelyTyped",
            "{0}js".format(project_name),
            typedesc_file_name)
    if os.path.exists(typedesc_file_path):
        return typedesc_file_path

    return None 


# Returns the version number of the project the typedesc_file describes
# Returns None if the version number cannot be found
def get_typedesc_version_number(project_name, typedesc_file):
    header = _read_first_n_lines(typedesc_file, 4) 
    regexp_str = "(?:(?:" + project_name + "(?:\s*(?:\.js|js))?))\s((?:[v])?)((?:\d+\.?){1,3})"
    if project_name.endswith("js"):
        regexp_str = "((?:(?:" + project_name + "(?:\s*(?:\.js|js))?))|(?:(?:" + project_name[0: len(project_name) - 2] + "(?:\s*(?:\.js|js))?)))\s((?:[v])?)((?:\d+\.?){1,3})"
    regexp = re.compile(regexp_str, re.IGNORECASE | re.MULTILINE)
    match = re.search(regexp, header)
    if match is None:
        print("Couldn't find a version number")
        print(header)
        print("RegExp: ")
        print(regexp_str)
        print("")
        return None
    result = match.group(2)
    
    try:
        if not match.group(2): 
            result = match.group(3)
        if not match.group(3):
            print ("Unable to find version number")
            return None;
    except Exception as e:
        1+2 # No group 3, this is OK. 
    
    result = str(result)
    # Ignoring patch versions. 
    if (len(result.split(".")) >= 3): 
        result = result.split(".")[0] + "." + result.split(".")[1]
    
    print("Resulting .d.ts version: " + result)
    return result


def _read_first_n_lines(file_path, n):
    lines = ""
    with open(file_path, 'r') as f:
        for i in range(0, n):
            lines += f.readline()
    return lines
